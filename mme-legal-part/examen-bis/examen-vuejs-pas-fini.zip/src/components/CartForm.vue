<template>
  <form>
    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="categories">Catégorie</label>
          <select class="form-control" id="categories" @change="onChange($event)">
            <option
              :value="index"
              v-for="(data, index) in this.datas"
              :key="data.category"
            >
              {{ data.category }}
            </option>
          </select>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="products">Produit</label>
          <select class="form-control" id="products">
            <option
              :value="data.price"
              v-for="data in this.products"
              :key="data.libelle"
            >
              {{ data.libelle }}
            </option>
          </select>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6">
        <label for="quantity">Quantité</label>
        <input
          type="nimber"
          class="form-control"
          id="quantity"
          min="0"
          max="100"
        />
      </div>
      <div class="col-md-6 vcenter">
        <div class="row d-flex center">
          <div class="col-md-6">
            <button class="btn btn-secondary btn-lg btn-block">
              Réinitialiser
            </button>
          </div>
          <div class="col-md-6">
            <button type="submit" class="btn btn-primary btn-lg btn-block">
              Ajouter
            </button>
          </div>
        </div>
      </div>
    </div>
  </form>
</template>

<script>
export default {
  name: "CartForm",
  data: function() {
    return {
      products: this.datas[0].products
    }
  },
  props: {
    datas: Array,
  },
  methods: {
    onChange(event) {
      let newProducts = [];
      this.datas[event.target.value].products.forEach(product => {
        newProducts.push(product);
      });
      this.products = newProducts;
    }
  },
};
</script>

<style scoped>
.row.center {
  position: absolute;
  width: 100%;
  top: 32%;
}
</style>