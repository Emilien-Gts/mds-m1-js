<template>
  <tr>
    <th scope="row">{{ data.id }}</th>
    <td>{{ data.libelle }}</td>
    <td>{{ data.quantity }}</td>
    <td>{{ totalPrice }}</td>
  </tr>
</template>

<script>
export default {
    name: "CartTableItem",
    props: {
      data: Object
    },
    computed: {
      totalPrice: function() {
        return this.data.priceOnlyOne * this.data.quantity;
      }
    }
};
</script>

<style scoped>
</style>